
from django import forms
from .models import Pokemon


class PokemonForm(forms.ModelForm):
    class Meta:
        model = Pokemon
        fields = [
            'nombre',
            'peso',
            'entrenado',
            'habilidades',
            'naturaleza',
            'descripcion',
        ]

        labels = {
            'nombre': 'Nombre del Pokémon',
            'peso': 'Peso (kg)',
            'entrenado': '¿Está entrenado?',
            'habilidades': 'Habilidades',
            'naturaleza': 'Naturaleza',
            'descripcion': 'Descripción',
        }

        widgets = {
            'nombre': forms.TextInput(attrs={
                'class': 'campo',
                'placeholder': 'Ej. Pikachu'
            }),
            'peso': forms.NumberInput(attrs={
                'class': 'campo',
                'placeholder': 'Ej. 6.0',
                'step': '0.1'
            }),
            'entrenado': forms.CheckboxInput(attrs={
                'class': 'casilla'
            }),
            'habilidades': forms.Textarea(attrs={
                'class': 'campo',
                'placeholder': 'Escribe las habilidades',
                'rows': 3
            }),
            'naturaleza': forms.TextInput(attrs={
                'class': 'campo',
                'placeholder': 'Ej. Alegre'
            }),
            'descripcion': forms.Textarea(attrs={
                'class': 'campo',
                'placeholder': 'Describe al Pokémon',
                'rows': 4
            }),
        }
