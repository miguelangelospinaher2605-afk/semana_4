
from django.shortcuts import render, redirect
from .forms import PokemonForm

def inicio(request):
    return render(request, 'pok_app/index.html')

def registrar_pokemon(request):
    if request.method == 'POST':
        formulario = PokemonForm(request.POST)

        if formulario.is_valid():
            formulario.save()
            return redirect('registrar_pokemon')
    else:
        formulario = PokemonForm()

    return render(
        request,
        'pok_app/registrar_pokemon.html',
        {'formulario': formulario}
    )

def detalle_pokemon(request, nombre):
    return render(request, 'pok_app/detalle_pokemon.html', {
        'nombre_pokemon': nombre
    })


def pokemon_aleatorio(request):
    return render(request, 'pok_app/pokemon_aleatorio.html')

    

