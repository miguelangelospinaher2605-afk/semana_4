
from django.db import models


class Pokemon(models.Model):
    nombre = models.CharField(max_length=100)
    peso = models.FloatField()
    entrenado = models.BooleanField(default=False)
    habilidades = models.TextField()
    naturaleza = models.CharField(max_length=100)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre


class Gimnasio(models.Model):
    lider_gym = models.CharField(max_length=100)
    naturaleza = models.CharField(max_length=100)
    medallas = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.lider_gym


class Entrenador(models.Model):
    id_documento = models.CharField(max_length=20, primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    pokemones = models.ManyToManyField(Pokemon, blank=True)
    medallas = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"



