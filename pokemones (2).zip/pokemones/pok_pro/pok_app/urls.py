from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),

    path('registrar-pokemon/',
         views.registrar_pokemon,
         name='registrar_pokemon'),

    path('pokemon/<str:nombre>/',
         views.detalle_pokemon,
         name='detalle_pokemon'),
]